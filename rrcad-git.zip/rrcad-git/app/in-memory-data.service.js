"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var InMemoryDataService = /** @class */ (function () {
    function InMemoryDataService() {
    }
    InMemoryDataService.prototype.createDb = function () {
        var clientes = [
            { id: 1, codigo: 3, nome: 'AMAZON', dtalteracao: '2017-06-06 15:55:56.0', dtinclusao: '2017-06-06 15:55:56.0', },
            { id: 2, codigo: 1, nome: 'MOVILE', dtalteracao: '2017-06-06 15:55:56.0', dtinclusao: '2017-06-06 15:55:56.0', },
            { id: 3, codigo: 2, nome: 'EXCHANGE', dtalteracao: '2017-06-06 15:55:56.0', dtinclusao: '2017-06-06 15:55:56.0', },
            { id: 4, codigo: 6, nome: 'Microsoft', dtalteracao: '2017-12-28 12:19:48.404', dtinclusao: '2017-12-28 12:19:48.404', },
        ];
        return { clientes: clientes };
    };
    return InMemoryDataService;
}());
exports.InMemoryDataService = InMemoryDataService;
//# sourceMappingURL=in-memory-data.service.js.map