export class Cliente {

    constructor(
        public id:number,
        public codigo:number,
        public nome: string,
        public dtinclusao : string,
        public dtalteracao : string
    ){}
}