"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Cliente = /** @class */ (function () {
    function Cliente(id, codigo, nome, dtinclusao, dtalteracao) {
        this.id = id;
        this.codigo = codigo;
        this.nome = nome;
        this.dtinclusao = dtinclusao;
        this.dtalteracao = dtalteracao;
    }
    return Cliente;
}());
exports.Cliente = Cliente;
//# sourceMappingURL=cliente.model.js.map