import { Brokers2Component } from './brokers2.component';
import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';

import { Brokers2ListaComponent } from './brokers2-lista/brokers2-lista.component';
import { Broker2DetalheComponent } from './broker2-detalhe/broker2-detalhe.component';

import { Broker2RoutingModule } from './broker2-routing.module';
import { Broker2Service } from './../services/broker2.service';
import { FormsModule} from '@angular/forms';

@NgModule({
    imports : [
        CommonModule,
        Broker2RoutingModule,
        FormsModule
    ],
     declarations : [
         Brokers2ListaComponent,
         Broker2DetalheComponent,
         Brokers2Component
     ],
     exports : [
        Brokers2ListaComponent],
     providers: [
         Broker2Service
     ]
})
export class Brokers2Module {}
