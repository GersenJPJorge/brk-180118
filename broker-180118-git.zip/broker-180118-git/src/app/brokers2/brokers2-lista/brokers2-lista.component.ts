import { Component, OnInit } from '@angular/core';
import { DialogConfirmService } from './../../services/dialogconfirme.service';
import { Broker } from './../../models/broker2-model';
import { Broker2Service } from './../../services/broker2.service';

@Component({
  selector: 'app-brokers2-lista',
  templateUrl: './brokers2-lista.component.html'
})
export class Brokers2ListaComponent implements OnInit {

  brokers: Broker[] ;

  constructor(
      private brokerService: Broker2Service,
      private dialogconfirmService:  DialogConfirmService
      ) {}

  ngOnInit(): void {
      this.brokerService.getBrokers()
      .then((brokers: Broker[]) => {
          this.brokers = brokers;
      }).catch(err => console.log(err));
  }
  onDelete(broker: Broker): void {
     this.dialogconfirmService.confirm('Deseja excluir o broker ' + broker.nome + ' ?')
     .then((podeDeletar: boolean) => {
         if(podeDeletar) {
             this.brokerService
             .delete(broker)
             .then(()=> {
                  this.brokers = this.brokers.filter((c:Broker) => c.id != broker.id);
             }).catch(err => {
                console.log(err);
             });
         }
     });
  }
}
