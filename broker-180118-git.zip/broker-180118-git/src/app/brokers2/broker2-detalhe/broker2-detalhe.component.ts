import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params} from '@angular/router';
import { Broker } from './../../models/broker2-model';
import { Broker2Service } from './../../services/broker2.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-broker2-detalhe',
  templateUrl: './broker2-detalhe.component.html'
})
export class Broker2DetalheComponent implements OnInit {


  broker : Broker;
  private isNovo : boolean= true;

  constructor(
     private brokerService : Broker2Service,
     private route : ActivatedRoute,
     private location : Location
  ) {}

   ngOnInit(): void {
       this.broker = new Broker(0,0,'','','',);
       this.route.params.forEach((params: Params)=>{
           let id: number = +params['id'];

      if(id){

       this.isNovo = false;

       this.brokerService.getBroker(id)
           .then((broker: Broker)=> {
                console.log(broker);
                this.broker = broker;
           });
      }
    });
}

getFormGroupClass(isValid : boolean, isPristine: boolean) : {} {
    return {
        'form-group' : true,
        'has-danger': !isValid && !isPristine,
        'has-success': isValid && !isPristine
    };
}

getFormControlClass(isValid : boolean, isPristine: boolean) : {} {
    return {
        'form-control' : true,
        'has-danger': !isValid && !isPristine,
        'has-success': isValid && !isPristine
    };
}

onSubmit() : void {
    let promise;
    if (this.isNovo) {
        console.log('cadastrar');
        promise = this.brokerService.create(this.broker);
    } else {
        console.log('alterar');
        promise = this.brokerService.update(this.broker);
    }
    promise.then(broker=> this.location.back());
}
}
