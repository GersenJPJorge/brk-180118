import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';

import { Brokers2ListaComponent} from './brokers2-lista/brokers2-lista.component';
import { Broker2DetalheComponent} from './broker2-detalhe/broker2-detalhe.component';

const brokerRoutes: Routes =[
  {
      path : 'broker',
      component: Brokers2ListaComponent
  },
  {
      path : 'broker/salvar',
      component: Broker2DetalheComponent
  },
  {
      path : 'broker/salvar/:id',
      component: Broker2DetalheComponent
  }
]

@NgModule({
    imports: [
        RouterModule.forChild(brokerRoutes)
    ],
    exports : [RouterModule]
})

export class Broker2RoutingModule {}
