import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brokers2',
  templateUrl: './brokers2.component.html',
  styleUrls: ['./brokers2.component.css']
})
export class Brokers2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
