import { BaseResponseModel } from './BaseResponseModel';

export class BrokerDataModel extends BaseResponseModel {

  user: {
    codigoBroker: number;
    datAlteracao: string;
    nomeBroker: string;
    datInclusao: string;
};

}
