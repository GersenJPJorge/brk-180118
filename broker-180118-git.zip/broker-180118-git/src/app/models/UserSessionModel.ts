export class UserSessionModel {
  constructor(public username: string, public token: string) {
  }
}
