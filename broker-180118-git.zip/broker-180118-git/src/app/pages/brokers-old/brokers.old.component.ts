import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';

import { Usuario } from '../login/usuario';
import { TokenService } from '../../token.service';
import { BrokersOldService } from './brokers.old.service';

@Component({
  selector: 'app-brokers',
  templateUrl: './brokers.old.component.html',
  styleUrls: ['./brokers.old.component.css'],
  providers: [Usuario]
})

@Injectable()
export class BrokersOldComponent implements OnInit {

  constructor(private usuario: Usuario, public token: TokenService, private http: HttpClient, public brokers: BrokersOldService) { }

  ngOnInit() {
    const urlGetCompany = 'http://172.18.164.6:9082/cadu-orbitall/v1/broker';

    this.http.get(urlGetCompany, {
        headers: new HttpHeaders()
//        .set('Content-Type',                'application/x-www-form-urlencoded')
            .set('Content-Type',                'application/json ')
            .set('Authorization',               'Bearer ' + this.token.userToken + '')
            .set('systemName',                  'siteOle')
            .set('environmentName',             'hml')
            .set('productName',                 'appOrbitallCard')
            .set('Access-Control-Allow-Origin', '*')
            .set('Access-Control-Allow-Headers', 'urlGetCompany')
    })
    .subscribe(
      data => {
  //      this.listBroker = data[0];
        this.brokers = data['------------------------> retorno']['listBroker'];
        console.log('--------------------> data', data);
        console.log('-------------------------> HttpHeaders', HttpHeaders);
      },
      error => {
        console.log('-------------------> error', error);
        console.log('-------------------> HttpHeaders', HttpHeaders);
        console.log('Erro. Se persistir, entre em contato com o suporte técnico.');
      }
    );
  }

  // Função para inserir uma broker
  incluiBroker() {
    console.log('incluiBroker');
  }

  // Função para editar uma broker
  editaBroker() {
    console.log('editaBroker');
  }

  // Função para excluir uma broker
  excluiBroker() {
    console.log('excluiBroker');
  }

}



