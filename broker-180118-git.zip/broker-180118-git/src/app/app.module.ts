import { NgModule } from '@angular/core';
import { NgModel, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule, Title } from '@angular/platform-browser';
import { RoutingModule } from './app.router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { AppComponent } from './app.component';

import { MenuComponent } from './menu/menu.component';
import { ListaMenuComponent } from './menu/lista-menu/lista-menu.component';
import { HeaderMenuComponent } from './menu/header-menu/header-menu.component';
import { FooterMenuComponent } from './menu/footer-menu/footer-menu.component';
import { UserAvatarComponent } from './menu/header-menu/user-avatar/user-avatar.component';

import { HeaderComponent } from './header/header.component';
import { BtnHeaderComponent } from './header/btn-header/btn-header.component';

import { LoginComponent } from './pages/login/login.component';
import { AuthService } from './pages/login/auth.service';
import { AuthGuard } from './guards/auth-guard';
import { TokenService } from './token.service';

import { HomeComponent } from './pages/home/home.component';

// import { BrokersComponent } from './pages/brokers/brokers.component';
// import { BrokersService } from './pages/brokers/brokers.service';
// import { Brokers2Component } from './brokers2/brokers2.component';
import { Brokers2Module } from './brokers2/broker2-module';


@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    HeaderComponent,
    HeaderMenuComponent,
    UserAvatarComponent,
    ListaMenuComponent,
    BtnHeaderComponent,
    LoginComponent,
    HomeComponent,
    FooterMenuComponent,
//  BrokersComponent,,
//  Brokers2Component
],
  imports: [
    BrowserModule,
    AngularFontAwesomeModule,
    FormsModule,
    RoutingModule,
    HttpClientModule,
    NgbModule.forRoot(),
    Brokers2Module
  ],
  providers: [
    Title,
    AuthService,
    AuthGuard,
    TokenService,
//    BrokersService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
