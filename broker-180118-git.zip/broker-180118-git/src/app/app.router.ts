import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { AuthGuard } from './guards/auth-guard';
import { Brokers2Component } from './brokers2/brokers2.component';

const Approutes: Routes = [
    // home
    {
        path: '',
        component: HomeComponent,
        canActivate: [AuthGuard],
        data: {title: 'Home'}
    },
    // login
    {
        path: 'login',
        component: LoginComponent,
        data: {title: 'Login'}
    },
    // logout
    {
        path: 'logout',
        component: LoginComponent,
        data: {title: 'Logout'}
    },
    // brokers
//    {
//        path: 'brokers2',
//        component: Brokers2Component,
//        canActivate: [AuthGuard],
//        data: {title: 'Brokers2'}
//    },
];

export const RoutingModule = RouterModule.forRoot(Approutes);
