/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { DialogconfirmeService } from './dialogconfirme.service';

describe('Service: Dialogconfirme', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DialogconfirmeService]
    });
  });

  it('should ...', inject([DialogconfirmeService], (service: DialogconfirmeService) => {
    expect(service).toBeTruthy();
  }));
});