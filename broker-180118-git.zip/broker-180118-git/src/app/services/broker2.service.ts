import { Http, Headers, Response } from '@angular/http';
import { Injectable } from '@angular/core';

import 'rxjs/add/operator/toPromise';

import { Broker } from './../models/broker2-model';
import { CLIENTES } from './../brokers2/broker2-mock';


@Injectable()
export class Broker2Service {


   // app é a pasta de onde fizermos a chamada
   // brokers é o nome da variável na classe InMemoryDataService
   private brokersUrl : string = 'app/brokers';

   private headers: Headers = new Headers ({'Content-Type' : 'application/json'})

    constructor(
       private http: Http
    ) {}

    getBrokers() : Promise<Broker[]> {

       return this.http.get(this.brokersUrl)
         .toPromise()
         .then(response => response.json().data as Broker[])

         .catch(this.trataErro);
        }
      private trataErro(err : any): Promise<any> {
        console.log('Erro : ' , err );
          return Promise.reject(err.message || err );
        }

    getBroker(id:number): Promise<Broker> {
           return this.getBrokers()
           .then((brokers: Broker[]) => brokers.find(broker => broker.id === id));
          }

   create(broker: Broker): Promise<Broker> {
        return this.http.post(this.brokersUrl, JSON.stringify(broker), {headers:this.headers})
        .toPromise()
        .then((response : Response) => {
            console.log(response.json().data);
            return response.json().data as Broker;
        })
        .catch(this.trataErro);
    }
    update(broker: Broker): Promise<Broker> {
      const url = `${this.brokersUrl}/${broker.id}`; // app/broker/:id
      return this.http
      .put(url, JSON.stringify(broker), {headers:this.headers})
      .toPromise()
      .then(() => broker as Broker)
      .catch(this.trataErro);
  }
  delete(broker: Broker): Promise<Broker> {
    const url = `${this.brokersUrl}/${broker.id}`; // app/broker/:id
    return this.http
    .delete(url, {headers: this.headers})
    .toPromise()
    .then(() => broker as Broker)
    .catch(this.trataErro);
}
}
